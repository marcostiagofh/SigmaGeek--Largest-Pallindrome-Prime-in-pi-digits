#include "PublicLibs/ConsoleIO/BasicIO.h"
#include "PublicLibs/Exceptions/Exception.h"
#include "DigitViewer/DigitViewerUI2.h"
#include <time.h> 
using namespace ymp;

int main(int argc,  char *argv[]){
	time_t begin = time(NULL);
	
    try{

        //  Launch the main menu.
		
        DigitViewer2::Menu_Main(argv);

    }catch (Exception &e){
        e.print();
    }catch (std::exception &e){
        Console::print(e.what());
    }

    Console::println("\n");
	
	time_t end = time(NULL);
 
    printf("The elapsed time is %d seconds\n", (end - begin));
    
    //Console::Pause('w');
}

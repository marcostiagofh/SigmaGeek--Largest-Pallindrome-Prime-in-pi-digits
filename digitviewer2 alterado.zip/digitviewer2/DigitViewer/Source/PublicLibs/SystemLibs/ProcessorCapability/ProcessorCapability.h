/* ProcessorCapability.h
 * 
 * Author           : Alexander J. Yee
 * Date Created     : 04/17/2016
 * Last Modified    : 04/17/2016
 * 
 */

#pragma once
#ifndef ymp_ProcessorCapability_H
#define ymp_ProcessorCapability_H

#include "ProcessorCapability_x86.h"

#endif
